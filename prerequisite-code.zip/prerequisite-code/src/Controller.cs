﻿using Microsoft.AspNetCore.Mvc;

namespace Prerequisites
{
    public class Controller : ControllerBase
    {
        [HttpGet]
        [Route("")]
        public string Get() => "I'm installing dependencies";
    }
}