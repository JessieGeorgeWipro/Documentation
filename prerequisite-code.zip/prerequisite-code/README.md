# ![pal](images/pal-small.png) Welcome

This repository contains the code for PAL prerequisite exercises.
To complete the prerequisites, please visit our [prerequisite exercise](https://pal-prerequisites-v1.cfapps.io/).
